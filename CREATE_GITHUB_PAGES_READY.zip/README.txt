CREATE — GitHub Pages package
Upload the CONTENTS of this folder to the root of the Create_ repository:
index.html
.nojekyll
works/marea/index.html
Then GitHub Pages serves:
Home: https://infoarchitetturastudio-eng.github.io/Create_/
MAREA: https://infoarchitetturastudio-eng.github.io/Create_/works/marea/
